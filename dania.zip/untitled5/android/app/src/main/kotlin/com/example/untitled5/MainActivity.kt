package com.example.untitled5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
